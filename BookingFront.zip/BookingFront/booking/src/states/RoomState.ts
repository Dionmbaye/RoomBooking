import { Room } from "../domain/Room";

export default interface RoomState {
    rooms: Room[];
}